# ArthSetu — DeepMatrix

Vercel-ready static export of the ArthSetu rural entrepreneurship and financial advisory prototype.

## Deploy manually on Vercel
1. Open Vercel Dashboard.
2. Choose **Add New → Project**.
3. Upload this ZIP / project folder.
4. No build command is required.
5. Deploy.

The root page provides navigation to the 18 interactive Stitch HTML screens.
